function notify(notification) {
	iziToast.show(notification);
}