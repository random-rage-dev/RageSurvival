var materials = {};

materials[2379541433] = 1;
materials[127813971] = 2;
materials[3454750755] = 2;
materials[581794674] = 3;
//materials[581794674] = true;

module.exports = materials;