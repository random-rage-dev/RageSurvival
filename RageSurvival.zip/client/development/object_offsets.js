var offsets = {
	"sr_prop_sr_boxwood_01": {
		pos: new mp.Vector3(0, 0, 0),
		rot: new mp.Vector3(0, 0, 0)
	},
	"prop_box_wood04a": {
		pos: new mp.Vector3(0, 0, 0),
		rot: new mp.Vector3(0, 0, 0)
	}
}
module.exports = offsets;