"use strict";
var materials = {};

materials[2379541433] = "Tree";
materials[127813971] = "Stone";
materials[3454750755] = "Mineral Stone";
materials[581794674] = "Vegetation";

module.exports = materials;