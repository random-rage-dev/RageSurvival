"use strict";
/*
 *  Tiers : Residential,Industrial,Farm,Military,Other,Food,...
 */

var positions = [{
    "x":  1817.0567626953125,
    "y":  3795.816650390625,
    "z": 33.65483093261719,
    "id": 0
}]
module.exports = positions;